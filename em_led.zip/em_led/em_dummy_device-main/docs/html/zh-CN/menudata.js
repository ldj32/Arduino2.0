/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"首页",url:"index.html"},
{text:"类",url:"annotated.html",children:[
{text:"类列表",url:"annotated.html"},
{text:"类索引",url:"classes.html"},
{text:"类成员",url:"functions.html",children:[
{text:"全部",url:"functions.html"},
{text:"函数",url:"functions_func.html"},
{text:"枚举",url:"functions_enum.html"},
{text:"枚举值",url:"functions_eval.html"}]}]},
{text:"文件",url:"files.html",children:[
{text:"文件列表",url:"files.html"}]},
{text:"示例",url:"examples.html"},
{text:"下载",url:"usergroup0.html",children:[
{text:"EM_Dummy_Device_v1.0.3.zip: https://gh-proxy.com/https://github.com/emakefun-arduino-library/em_dummy_device/archive/refs/tags/v1.0.3.zip",url:"^https://gh-proxy.com/https://github.com/emakefun-arduino-library/em_dummy_device/archive/refs/tags/v1.0.3.zip"}]}]}
